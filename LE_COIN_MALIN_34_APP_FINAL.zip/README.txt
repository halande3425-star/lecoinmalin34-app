# LE COIN MALIN 34 — Pack final pour la nouvelle application

Ce package est destiné à la construction d'une **nouvelle application autonome**.

## Important
Le robot Telegram existant est volontairement exclu de ce package.
Aucun BOT_TOKEN, fichier de bot ou secret n'est fourni.

## Contenu
- `assets/catalog/` : données initiales utiles au catalogue
- `assets/branding/` : identité visuelle et images existantes
- `assets/reference-images/` : image fournie pour l'écran d'ouverture
- `docs/PROMPT_CONSTRUCTION_FR.txt` : prompt complet à fournir à l'outil de construction de l'application

## Règle
La nouvelle application ne doit pas se connecter au robot Telegram.
Les données/images présentes ici sont uniquement des sources initiales pour la nouvelle application.
